﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Application;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deur
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void Sleutelgerbuiken()
        {
            string Sleutel = txt1.Text;
            string Deurhendel  = txt2.Text;
            if (Sleutel == "Links")
            {
                lbl1.Text =
                        "Voordeur is Op slot deur is nog op slot" + "\n" +
                           "Deur is nog op slot en kan niet open" + "\n" +
                           "je stoot tegen de voordeur";
            }

            else if (Sleutel == "Rechts")
            {

                lbl1.Text =
                         "Voordeur is nog op slot" + "\n" +
                         "Deur is nog op slot en kan niet open" + "\n" +
                         "Je stoot tegen de Voordeur!";
            }
            if (Sleutel =="links" && Deurhendel == "draaien")
                
            {

                lbl1.Text =
                          "Deur is ontgrendeld" + "\n" +
                          "Deur is geopend!" + "\n" +
                          "Je stoot tegen de deur";
            }
            else if (Sleutel == "Rechts" && Deurhendel == "draaien") 
            {

                lbl1.Text =
                          "Deur is ontgrendeld" + "\n" +
                          "Deur is geopend!" + "\n" +
                          "Je bent in je huiskamer!";
            
            
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Sleutelgerbuiken();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            lbl1.Text = " ";
        }
    }

}   
